# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['encodex',
 'encodex.models',
 'encodex.train',
 'encodex.utils',
 'encodex.xasdata']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'encodex',
    'version': '0.2.0',
    'description': 'Update of EncodeX Library',
    'long_description': None,
    'author': 'Prahlad K. Routh, Ph.D.',
    'author_email': 'prahladkumar.routh@stonybrook.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
